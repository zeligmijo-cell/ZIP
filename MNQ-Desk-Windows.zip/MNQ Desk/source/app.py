"""Windows desktop UI for a personal MNQ bot."""
import json
import os
import queue
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from datetime import datetime
from core import Settings, Broker, Engine, Ledger, save_settings, load_settings, now, CT

DATA = Path(os.environ.get('LOCALAPPDATA',str(Path.cwd()))) / 'MNQDesk'

class App:
    def __init__(self, root, data_dir=DATA):
        self.root, self.data_dir = root, Path(data_dir)
        self.data_dir.mkdir(parents=True,exist_ok=True)
        self.events = queue.Queue()
        self.engine = None
        self.thread = None
        self.busy = False
        self.accounts = {}
        self.contracts = {}
        self.vars = {}
        self.edits = []
        self.ledger = Ledger(self.data_dir/'execution-ledger.json')
        try:
            self.settings = load_settings(self.data_dir/'settings.json')
            self.load_error = ''
        except Exception as e:
            self.settings = Settings()
            self.load_error = str(e)
        root.title('MNQ Desk • Personal trading console')
        root.geometry('1120x830')
        root.minsize(980,740)
        root.configure(bg='#101823')
        self.style()
        self.build()
        self.log('Ready. Strategy is required. Broker execution starts only after you choose Broker orders and press Start.')
        self.log('TopstepX provides market data AND order execution. Only eligible simulated accounts are supported.')
        if self.load_error:
            self.log('Saved settings could not be loaded: '+self.load_error)
        if self.ledger.data.get('pending'):
            self.log('An unresolved order is recorded. Reconcile before starting another entry.')
        root.protocol('WM_DELETE_WINDOW',self.close)
        root.after(100,self.drain)

    def style(self):
        st = ttk.Style(self.root)
        st.theme_use('clam')
        st.configure('.',background='#182332',foreground='#eef3fa',font=('Segoe UI',10))
        st.configure('TFrame',background='#182332')
        st.configure('TLabel',background='#182332',foreground='#eef3fa')
        st.configure('Muted.TLabel',foreground='#a4b3c6')
        st.configure('Title.TLabel',font=('Segoe UI Semibold',23))
        st.configure('Price.TLabel',font=('Segoe UI Semibold',21),foreground='#53d6ba')
        st.configure('TButton',padding=(15,8),background='#2b4059')
        st.map('TButton',background=[('active','#3b5574'),('disabled','#202b3a')])
        st.configure('Go.TButton',background='#157a65',foreground='white')
        st.configure('Stop.TButton',background='#843747',foreground='white')
        st.configure('TEntry',fieldbackground='#101823',foreground='#f2f6fb',insertcolor='white',padding=5)
        st.configure('TCombobox',fieldbackground='#101823',foreground='#f2f6fb',padding=5)
        st.map('TCombobox',fieldbackground=[('readonly','#101823')],foreground=[('readonly','#f2f6fb')])
        st.configure('TNotebook',background='#101823',borderwidth=0)
        st.configure('TNotebook.Tab',padding=(18,10),background='#202f42')
        st.map('TNotebook.Tab',background=[('selected','#335271')])
        st.configure('TCheckbutton',background='#182332',foreground='#eef3fa')

    def build(self):
        shell = ttk.Frame(self.root,padding=22)
        shell.pack(fill='both',expand=True,padx=12,pady=12)
        header = ttk.Frame(shell)
        header.pack(fill='x')
        left = ttk.Frame(header)
        left.pack(side='left')
        ttk.Label(left,text='MNQ DESK',style='Title.TLabel').pack(anchor='w')
        ttk.Label(left,text='Your device. Your strategy. TopstepX execution.',style='Muted.TLabel').pack(anchor='w',pady=(2,12))
        right = ttk.Frame(header)
        right.pack(side='right')
        self.price = tk.StringVar(value='MNQ  —')
        ttk.Label(right,textvariable=self.price,style='Price.TLabel').pack(anchor='e')
        self.quote_time = tk.StringVar(value='TopstepX feed • 5-second cycle plus request time')
        ttk.Label(right,textvariable=self.quote_time,style='Muted.TLabel').pack(anchor='e')
        self.status_var = tk.StringVar(value='STOPPED • Preview only')
        ttk.Label(shell,textvariable=self.status_var,font=('Segoe UI Semibold',11)).pack(fill='x',pady=(3,12))
        self.book = ttk.Notebook(shell)
        self.book.pack(fill='both',expand=True)
        connections = ttk.Frame(self.book,padding=20)
        strategy = ttk.Frame(self.book,padding=20)
        risk = ttk.Frame(self.book,padding=20)
        journal = ttk.Frame(self.book,padding=20)
        for frame,title in ((connections,'01  Connections'),(strategy,'02  Strategy'),(risk,'03  Risk & schedule'),(journal,'04  Activity')):
            self.book.add(frame,text=title)
        connections.columnconfigure(1,weight=1)
        connections.columnconfigure(3,weight=1)
        ttk.Label(connections,text='TOPSTEPX / PROJECTX',font=('Segoe UI Semibold',11)).grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,8))
        self.field(connections,1,'TopstepX API address','broker_url',span=3)
        self.field(connections,2,'TopstepX username','username',span=3)
        self.field(connections,3,'TopstepX API key','broker_key',span=3,secret=True)
        ttk.Label(connections,text='CLAUDE / ANTHROPIC',font=('Segoe UI Semibold',11)).grid(row=4,column=0,columnspan=4,sticky='w',pady=(17,8))
        self.field(connections,5,'Anthropic API address','anthropic_url',span=3)
        self.field(connections,6,'Anthropic API key','anthropic_key',span=3,secret=True)
        self.field(connections,7,'Claude model ID','model')
        self.field(connections,7,'Workspace ID (optional)','workspace',col=2)
        ttk.Label(connections,text='ACCOUNT & INSTRUMENT',font=('Segoe UI Semibold',11)).grid(row=8,column=0,columnspan=4,sticky='w',pady=(17,8))
        self.account_var = tk.StringVar(value=str(self.settings.account_id) if self.settings.account_id else '')
        self.contract_var = tk.StringVar(value=self.settings.contract_id)
        ttk.Label(connections,text='Account').grid(row=9,column=0,sticky='w')
        self.account_combo = ttk.Combobox(connections,textvariable=self.account_var,state='readonly',width=35)
        self.account_combo.grid(row=9,column=1,sticky='ew',padx=(0,14),pady=5)
        ttk.Label(connections,text='Active MNQ contract').grid(row=9,column=2,sticky='w')
        self.contract_combo = ttk.Combobox(connections,textvariable=self.contract_var,state='readonly',width=27)
        self.contract_combo.grid(row=9,column=3,sticky='ew',pady=5)
        self.edits += [self.account_combo,self.contract_combo]
        self.connect_btn = ttk.Button(connections,text='Connect & find accounts',command=self.connect)
        self.connect_btn.grid(row=10,column=0,columnspan=2,sticky='w',pady=12)
        ttk.Label(connections,text='Keys are saved with Windows user encryption.\nNo keys or account identifiers are sent to Claude.',style='Muted.TLabel').grid(row=10,column=2,columnspan=2,sticky='w')
        ttk.Label(strategy,text='Describe the strategy',font=('Segoe UI Semibold',15)).pack(anchor='w')
        ttk.Label(strategy,text='Leave this blank until your strategy is ready. The bot will not start with an empty strategy.',style='Muted.TLabel').pack(anchor='w',pady=(6,12))
        self.strategy_text = tk.Text(strategy,height=12,wrap='word',bg='#101823',fg='#eef3fa',insertbackground='white',
                                     relief='flat',font=('Segoe UI',11),padx=14,pady=14)
        self.strategy_text.pack(fill='both',expand=True)
        self.strategy_text.insert('1.0',self.settings.strategy)
        self.edits.append(self.strategy_text)
        ttk.Label(strategy,text='Specify entry conditions, when to hold, timeframe, and indicators. Claude receives OHLCV candles only.\nSize, fixed stop, target and trading hours come from Risk & schedule; the strategy cannot override them.',style='Muted.TLabel').pack(anchor='w',pady=12)
        row = ttk.Frame(strategy)
        row.pack(fill='x')
        ttk.Label(row,text='Execution mode').pack(side='left',padx=(0,12))
        self.vars['mode'] = tk.StringVar(value='Preview only')
        mode = ttk.Combobox(row,textvariable=self.vars['mode'],values=['Preview only','Broker orders'],state='readonly',width=22)
        mode.pack(side='left')
        self.edits.append(mode)
        ttk.Label(row,text='Preview still uses paid Claude calls; it never submits orders.',style='Muted.TLabel').pack(side='left',padx=16)
        self.vars['oco_confirmed'] = tk.BooleanVar(value=self.settings.oco_confirmed)
        check = ttk.Checkbutton(strategy,text='I enabled Auto OCO Brackets in TopstepX → Settings → Risk Settings.',variable=self.vars['oco_confirmed'])
        check.pack(anchor='w',pady=(14,0))
        self.edits.append(check)
        risk.columnconfigure(1,weight=1)
        risk.columnconfigure(3,weight=1)
        ttk.Label(risk,text='Hard limits applied locally',font=('Segoe UI Semibold',15)).grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,15))
        pairs=[('MNQ contracts','quantity','Stop loss (ticks)','stop_ticks'),
               ('Profit target (ticks)','target_ticks','Max planned risk / trade ($)','max_risk'),
               ('Fee/slippage buffer / contract ($)','fee_buffer','Session loss guard ($)','daily_loss'),
               ('Account balance floor ($)','minimum_balance','Max entries / session','max_entries'),
               ('Entry cooldown (seconds)','cooldown','Claude calls / session cap','max_ai_calls'),
               ('Candle interval (minutes)','bar_minutes','Lookback (completed candles)','lookback'),
               ('Start time (Chicago, HH:MM)','start_time','End + flatten time (Chicago)','end_time')]
        for i,(a,k,b,l) in enumerate(pairs,1):
            self.field(risk,i,a,k)
            self.field(risk,i,b,l,col=2)
        ttk.Label(risk,text='MNQ: 0.25 point/tick • $0.50/tick/contract. Defaults are examples, not a trading recommendation.\nSession resets at 17:00 Chicago. Loss guard uses account realized P&L + selected MNQ unrealized P&L.\nSet the floor from your actual drawdown threshold. This app does not calculate Topstep trailing drawdown.\nOnly one entry while the entire account is flat and has no active orders. No scaling, reversals or HFT.',style='Muted.TLabel',wraplength=990).grid(row=9,column=0,columnspan=4,sticky='w',pady=(18,4))
        ttk.Label(risk,text='Keep the app running for scheduled flattening. Stop pauses the bot and leaves broker protection in place.\nThe loss guard blocks new entries; it does not promise a maximum loss or automatically close a position.',style='Muted.TLabel',wraplength=990).grid(row=10,column=0,columnspan=4,sticky='w',pady=4)
        self.risk_var = tk.StringVar(value='Connect to view account state.')
        ttk.Label(journal,textvariable=self.risk_var,wraplength=980).pack(fill='x',pady=(0,12))
        self.decision_var = tk.StringVar(value='Latest decision: —')
        ttk.Label(journal,textvariable=self.decision_var,wraplength=980,font=('Segoe UI Semibold',11)).pack(fill='x',pady=(0,12))
        self.logs = tk.Text(journal,height=13,wrap='word',bg='#101823',fg='#d5dfec',relief='flat',font=('Consolas',10),padx=10,pady=10,state='disabled')
        self.logs.pack(fill='both',expand=True)
        actions = ttk.Frame(journal)
        actions.pack(fill='x',pady=(12,0))
        self.reconcile_btn = ttk.Button(actions,text='Reconcile previous order',command=self.reconcile)
        self.reconcile_btn.pack(side='left')
        ttk.Button(actions,text='Open local journal folder',command=lambda:os.startfile(self.data_dir)).pack(side='left',padx=12)
        footer = ttk.Frame(shell)
        footer.pack(fill='x',pady=(17,0))
        self.save_btn = ttk.Button(footer,text='Save settings',command=self.save)
        self.save_btn.pack(side='left')
        self.start_btn = ttk.Button(footer,text='Start',style='Go.TButton',command=self.start)
        self.start_btn.pack(side='right',padx=(12,0))
        self.stop_btn = ttk.Button(footer,text='Stop',command=self.stop,state='disabled')
        self.stop_btn.pack(side='right',padx=(12,0))
        self.flat_btn = ttk.Button(footer,text='Stop + flatten MNQ',style='Stop.TButton',command=self.flatten)
        self.flat_btn.pack(side='right')

    def field(self, frame, row, label, key, col=0, span=1, secret=False):
        ttk.Label(frame,text=label).grid(row=row,column=col,sticky='w',padx=(0,12),pady=5)
        var = tk.StringVar(value=str(getattr(self.settings,key)))
        self.vars[key] = var
        entry = ttk.Entry(frame,textvariable=var,show='•' if secret else '',width=23)
        entry.grid(row=row,column=col+1,columnspan=span,sticky='ew',padx=(0,14) if col==0 and span==1 else 0,pady=5)
        self.edits.append(entry)

    def collect(self):
        d = {}
        defaults = Settings()
        for k,v in self.vars.items():
            value = v.get()
            baseline = getattr(defaults,k)
            try:
                d[k] = bool(value) if type(baseline)==bool else int(value) if type(baseline)==int else float(value) if type(baseline)==float else value.strip()
            except ValueError:
                raise ValueError(f'{k.replace("_"," ")} must be a number.')
        d['strategy'] = self.strategy_text.get('1.0','end').strip()
        a = self.account_var.get()
        c = self.contract_var.get()
        d['account_id'] = self.accounts[a]['id'] if a in self.accounts else self.settings.account_id
        d['contract_id'] = self.contracts[c]['id'] if c in self.contracts else self.settings.contract_id
        s = Settings(**d)
        s.validate()
        return s

    def emit(self,kind,value):
        self.events.put((kind,value))

    def log(self,msg):
        # Mask any currently configured key even if it appears in a model explanation.
        for key in ('broker_key','anthropic_key'):
            secret = self.vars[key].get() if key in self.vars else ''
            if secret:
                msg = msg.replace(secret,'[REDACTED]')
        line = datetime.now(CT).strftime('%H:%M:%S')+'  '+msg+'\n'
        self.logs.configure(state='normal')
        self.logs.insert('end',line)
        self.logs.see('end')
        self.logs.configure(state='disabled')
        with (self.data_dir/'activity.log').open('a',encoding='utf-8') as f:
            f.write(line)

    def set_busy(self,value):
        self.busy = value
        for w in self.edits:
            if isinstance(w,tk.Text):
                w.configure(state='disabled' if value else 'normal')
            else:
                w.configure(state='disabled' if value else 'readonly' if isinstance(w,ttk.Combobox) else 'normal')
        for w in (self.connect_btn,self.save_btn,self.start_btn,self.reconcile_btn):
            w.configure(state='disabled' if value else 'normal')
        self.stop_btn.configure(state='normal' if self.thread and self.thread.is_alive() else 'disabled')

    def task(self,fn):
        if self.busy:
            return
        self.set_busy(True)
        def work():
            try:
                fn()
            except Exception as e:
                self.emit('error',str(e))
            finally:
                self.emit('idle',None)
        threading.Thread(target=work,daemon=True).start()

    def save(self):
        try:
            self.settings = self.collect()
            save_settings(self.data_dir/'settings.json',self.settings)
            self.log('Settings saved. Execution mode resets to Preview only each time the app opens.')
        except Exception as e:
            messagebox.showerror('Settings',str(e))

    def connect(self):
        try:
            s = self.collect()
            if not s.username or not s.broker_key:
                raise ValueError('Enter the TopstepX username and API key.')
        except Exception as e:
            messagebox.showerror('Connect',str(e))
            return
        self.log('Connecting to TopstepX and looking up eligible simulated accounts and active MNQ contracts…')
        def work():
            b = Broker(s)
            accounts = [a for a in b.accounts() if a.get('simulated') is True and a.get('canTrade') is True]
            contracts = b.contracts()
            if not accounts or not contracts:
                raise RuntimeError('No eligible accounts or active MNQ contracts returned.')
            self.emit('connected',(accounts,contracts,s))
        self.task(work)

    def start(self):
        if self.busy:
            return
        try:
            s = self.collect()
            s.validate(True)
            if self.ledger.data.get('pending'):
                raise ValueError('Reconcile the previous order first in Activity.')
            save_settings(self.data_dir/'settings.json',s)
            if s.mode=='Broker orders':
                approved = messagebox.askyesno('Start automatic broker trading',
                    f'Account: {s.account_id}\nContract: {s.contract_id}\nQuantity: {s.quantity} MNQ\n'
                    f'Stop / target: {s.stop_ticks} / {s.target_ticks} ticks\n\n'
                    'After Start, the bot may place orders automatically without individual approval.\n'
                    'Confirm this account and your Topstep risk limits before continuing. Start now?')
                if not approved:
                    return
            self.settings = s
            self.engine = Engine(s,self.ledger,self.emit)
            self.thread = threading.Thread(target=self.engine.run,daemon=True)
            self.thread.start()
            self.set_busy(True)
            self.status_var.set('RUNNING • '+s.mode)
            self.log('Started in '+s.mode+'. Settings are locked until stopped.')
            self.book.select(3)
        except Exception as e:
            messagebox.showerror('Start',str(e))

    def stop(self):
        if self.engine:
            self.engine.stop_event.set()
            self.status_var.set('STOPPING • any request already sent may complete')
            self.log('Stop requested. Broker-held positions and brackets remain in place.')

    def flatten(self):
        if self.busy and not (self.thread and self.thread.is_alive()):
            return
        try:
            s = self.engine.s if self.thread and self.thread.is_alive() else self.collect()
            if not s.account_id or not s.contract_id or s.mode!='Broker orders':
                raise ValueError('Select an account, MNQ contract and Broker orders mode first.')
            if not messagebox.askyesno('Close selected MNQ exposure',
                    f'Stop the bot and close {s.contract_id} on account {s.account_id}?\n'
                    'This also cancels remaining orders on this contract after flat is confirmed.\n'
                    'Any manual MNQ position on this contract is included.'):
                return
            eng = self.engine if self.thread and self.thread.is_alive() else Engine(s,self.ledger,self.emit)
            eng.stop_event.set()
            self.set_busy(True)
            self.flat_btn.configure(state='disabled')
            self.status_var.set('STOPPING & FLATTENING • waiting for broker confirmation')
            def work():
                try:
                    if self.thread and self.thread.is_alive():
                        self.thread.join(timeout=90)
                        if self.thread.is_alive():
                            raise RuntimeError('Worker is still waiting for a request. Use TopstepX directly to flatten.')
                    eng.flatten()
                except Exception as e:
                    self.emit('error',str(e))
                finally:
                    self.emit('flat_done',None)
            self.flattening = True
            threading.Thread(target=work,daemon=True).start()
        except Exception as e:
            messagebox.showerror('Flatten',str(e))

    def reconcile(self):
        try:
            s = self.collect()
            if not self.ledger.data.get('pending'):
                self.log('No unresolved order is recorded.')
                return
            def work():
                if not Engine(s,self.ledger,self.emit).reconcile():
                    self.emit('log','Previous order/position is still active. Keep the existing broker protection; inspect TopstepX.')
            self.task(work)
        except Exception as e:
            messagebox.showerror('Reconcile',str(e))

    def drain(self):
        try:
            while True:
                kind,value = self.events.get_nowait()
                if kind=='log':
                    self.log(value)
                elif kind=='error':
                    self.log('ATTENTION: '+value)
                    self.status_var.set('ATTENTION • stopped or operation failed')
                    messagebox.showerror('MNQ Desk',value)
                elif kind=='connected':
                    aa,cc,s = value
                    self.accounts = {f'{a["name"]} • {a["id"]}':a for a in aa}
                    self.contracts = {f'{c["name"]} • {c["id"]}':c for c in cc}
                    self.account_combo['values'] = list(self.accounts)
                    self.contract_combo['values'] = list(self.contracts)
                    self.account_var.set(next((k for k,a in self.accounts.items() if a['id']==s.account_id),next(iter(self.accounts))))
                    self.contract_var.set(next((k for k,c in self.contracts.items() if c['id']==s.contract_id),next(iter(self.contracts))))
                    self.log('Connected. Choose your intended account before saving or starting.')
                elif kind=='price':
                    price,t = value
                    self.price.set(f'MNQ  {price:,.2f}')
                    self.quote_time.set('TopstepX • observation '+t)
                elif kind=='risk':
                    realized,unrealized,balance,np,no = value
                    self.risk_var.set(f'Balance ${balance:,.2f}  |  Session realized (account) ${realized:,.2f}  |  MNQ unrealized estimate ${unrealized:,.2f}  |  Positions {np}  |  Active orders {no}')
                elif kind=='decision':
                    d,usage,calls,entries = value
                    self.decision_var.set(f'{d["action"]}: {d["reason"][:300]}')
                    self.log(f'Claude: {d["action"]} — {d["reason"][:1200]} | session calls {calls}, entry reservations {entries} | tokens in/out: {usage.get("input_tokens",0)}/{usage.get("output_tokens",0)}')
                elif kind=='stopped':
                    if not getattr(self,'flattening',False):
                        self.set_busy(False)
                        self.status_var.set('STOPPED • check TopstepX for any remaining position')
                    self.quote_time.set('Bot stopped • displayed price is no longer updating')
                elif kind=='idle':
                    self.set_busy(False)
                elif kind=='flat_done':
                    self.flattening = False
                    self.set_busy(False)
                    self.flat_btn.configure(state='normal')
                    self.status_var.set('STOPPED • inspect activity for flatten result')
        except queue.Empty:
            pass
        self.root.after(100,self.drain)

    def close(self):
        if self.busy or (self.thread and self.thread.is_alive()):
            messagebox.showinfo('Stop before closing','Press Stop and wait for the bot to stop before closing.\nUse Stop + flatten MNQ if you want to close the selected position.\nExisting broker brackets remain active, but scheduled flattening needs this app running.')
            return
        self.root.destroy()

def main():
    if len(sys.argv)==3 and sys.argv[1]=='--smoke-test':
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            root = tk.Tk()
            root.withdraw()
            app = App(root,directory)
            root.update()
            assert len(app.book.tabs())==4
            assert app.collect().mode=='Preview only'
            assert app.collect().strategy==''
            assert app.engine is None
            Path(sys.argv[2]).write_text(json.dumps({'ok':True,'tabs':4,'default_mode':'Preview only',
                        'strategy_blank':True,'broker_requests':0,'platform':sys.platform}),encoding='utf-8')
            root.destroy()
        return
    # A Windows named mutex prevents duplicate instances from placing overlapping orders.
    import ctypes
    kernel = ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p]
    kernel.CreateMutexW.restype = ctypes.c_void_p
    handle = kernel.CreateMutexW(None,False,'Local\\MNQDeskPersonalTradingConsole')
    if not handle:
        raise RuntimeError('Could not acquire the application instance lock.')
    if ctypes.get_last_error()==183:
        r = tk.Tk(); r.withdraw()
        messagebox.showinfo('MNQ Desk','MNQ Desk is already open. Use the existing window.')
        r.destroy()
        return
    try:
        root = tk.Tk()
        try:
            App(root)
        except Exception as e:
            messagebox.showerror('MNQ Desk startup',str(e))
            root.destroy()
            return
        root.mainloop()
    finally:
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel.CloseHandle(handle)

if __name__=='__main__':
    main()
