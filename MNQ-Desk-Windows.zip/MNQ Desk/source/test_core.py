import copy
import json
import tempfile
import unittest
from pathlib import Path
from datetime import timedelta, datetime
from unittest.mock import patch
from core import *

class FakeBroker:
    def __init__(self):
        self.placed = []
        self.positions = []
        self.active = []
        self.history = []
        self.loss = 0
        self.balance = 50000
        self.throw_order = False
        self.quote_offset = 0
        self.contract_rows = [{'id':'MNQ.TEST','name':'MNQZ6','tickSize':.25,'tickValue':.5,'activeContract':True}]
    def state(self):
        return {'id':1,'balance':self.balance,'simulated':True,'canTrade':True},self.positions,self.active
    def bars(self,minutes=1,count=60,seconds=False):
        t = now()-timedelta(seconds=2 if seconds else minutes*60)
        return [{'t':stamp(t-timedelta(seconds=i if seconds else i*minutes*60)),
                 'o':21000,'h':21001,'l':20999,'c':21000+self.quote_offset,'v':5} for i in reversed(range(count))]
    def pnl(self,start):
        return self.loss
    def contracts(self):
        return self.contract_rows
    def orders(self,statuses=None):
        return self.history if statuses is None else self.active
    def call(self,route,payload):
        if route=='Order/place':
            self.placed.append(copy.deepcopy(payload))
            if self.throw_order:
                raise RuntimeError('Connection dropped after send')
            return {'success':True,'orderId':23}
        if route=='Position/closeContract':
            self.positions=[]
        if route=='Position/searchOpen':
            return {'positions':self.positions}
        if route=='Order/cancel':
            self.active=[o for o in self.active if o['id']!=payload['orderId']]
        return {'success':True}

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.s = Settings(username='x',broker_key='k',anthropic_key='a',account_id=1,
                          contract_id='MNQ.TEST',strategy='My strategy',mode='Broker orders',oco_confirmed=True)
        self.ledger = Ledger(Path(self.temp.name)/'ledger.json')
        self.broker=FakeBroker()
        self.events=[]
        self.ai_calls=0
        def ai(*args):
            self.ai_calls+=1
            return {'action':'BUY','reason':'fixture'},{}
        self.engine=Engine(self.s,self.ledger,lambda *a:self.events.append(a),self.broker,ai)
        self.window=patch('core.in_window',return_value=True)
        self.window.start()
    def tearDown(self):
        self.window.stop()
        self.temp.cleanup()
    def test_blank_strategy_cannot_start(self):
        self.s.strategy=' '
        with self.assertRaises(ValueError):self.s.validate(True)
    def test_risk_cap(self):
        self.s.quantity=10
        with self.assertRaises(ValueError):self.s.validate(True)
    def test_nonfinite_values(self):
        self.s.daily_loss=float('nan')
        with self.assertRaises(ValueError):self.s.validate(True)
    def test_preview_never_places(self):
        self.s.mode='Preview only'
        self.engine.cycle()
        self.assertEqual(self.broker.placed,[])
        self.assertEqual(self.ai_calls,1)
    def test_market_entry_has_brackets_and_durable_intent(self):
        self.engine.cycle()
        order=self.broker.placed[0]
        self.assertEqual(order['stopLossBracket'],{'ticks':40,'type':4})
        self.assertEqual(order['takeProfitBracket'],{'ticks':80,'type':1})
        self.assertEqual(order['side'],0)
        self.assertEqual(Ledger(self.ledger.path).data['pending']['payload'],order)
    def test_unknown_order_not_retried_after_restart(self):
        self.broker.throw_order=True
        with self.assertRaises(RuntimeError):self.engine.cycle()
        restart=Engine(self.s,Ledger(self.ledger.path),lambda *a:None,self.broker)
        with self.assertRaises(RuntimeError):restart.cycle()
        self.assertEqual(len(self.broker.placed),1)
    def test_open_exposure_blocks_ai(self):
        self.broker.positions=[{'contractId':'OTHER'}]
        self.engine.cycle()
        self.assertEqual(self.ai_calls,0)
    def test_stale_data_blocks(self):
        with patch('core.fresh',side_effect=RuntimeError('stale')):
            with self.assertRaises(RuntimeError):self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_daily_loss_blocks(self):
        self.broker.loss=-100
        with self.assertRaises(RuntimeError):self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_remaining_risk_room_blocks(self):
        self.broker.loss=-90
        self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_balance_floor_blocks(self):
        self.broker.balance=-1100
        with self.assertRaises(RuntimeError):self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_stop_during_inference(self):
        def ai(*args):
            self.engine.stop_event.set()
            return {'action':'BUY','reason':'fixture'},{}
        self.engine.ai=ai
        self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_price_move_after_inference_blocks(self):
        def ai(*args):
            self.broker.quote_offset=100
            return {'action':'BUY','reason':'fixture'},{}
        self.engine.ai=ai
        self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_new_position_after_inference_blocks(self):
        def ai(*args):
            self.broker.positions=[{'contractId':'OTHER'}]
            return {'action':'BUY','reason':'fixture'},{}
        self.engine.ai=ai
        self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_same_bar_once_persists(self):
        self.s.mode='Preview only'
        fixed=datetime(2026,10,8,15,0,tzinfo=UTC)
        with patch('core.now',return_value=fixed), patch('test_core.now',return_value=fixed):
            self.engine.cycle()
            self.engine.cycle()
        self.assertEqual(self.ai_calls,1)
    def test_ledger_io_failure_prevents_order(self):
        # First persistence is the AI budget. The second is the order intent.
        original=self.ledger.save
        calls=[]
        def save():
            calls.append(1)
            if len(calls)==2:raise OSError('disk full')
            original()
        self.ledger.save=save
        with self.assertRaises(OSError):self.engine.cycle()
        self.assertFalse(self.broker.placed)
    def test_reconciliation_requires_terminal_and_flat(self):
        self.engine.cycle()
        tag=self.broker.placed[0]['customTag']
        self.broker.history=[{'customTag':tag,'status':1}]
        self.assertFalse(self.engine.reconcile())
        self.broker.history[0]['status']=2
        self.broker.positions=[{'contractId':'MNQ.TEST'}]
        self.assertFalse(self.engine.reconcile())
        self.broker.positions=[]
        self.assertTrue(self.engine.reconcile())
        self.assertIsNone(self.ledger.data['pending'])
    def test_model_response_validation(self):
        bad=[{'stop_reason':'end_turn','content':[{'type':'text','text':'BUY'}]},
             {'stop_reason':'tool_use','content':[{'type':'tool_use','name':'record_decision','input':{'action':'BUY','reason':'ok','size':20}}]},
             {'stop_reason':'tool_use','content':[{'type':'tool_use','name':'record_decision','input':{'action':'EXEC','reason':'ok'}}]}]
        for response in bad:
            with self.assertRaises(RuntimeError):
                decision(self.s,[],21000,lambda *a,**k:response)
    def test_claude_receives_no_account_or_keys(self):
        seen=[]
        def transport(url,payload,headers,**kwargs):
            seen.append(payload)
            return {'stop_reason':'tool_use','content':[{'type':'tool_use','name':'record_decision','input':{'action':'HOLD','reason':'ok'}}]}
        decision(self.s,[],21000,transport)
        body=json.loads(seen[0]['messages'][0]['content'])
        self.assertNotIn('account_id',body)
        self.assertNotIn('broker_key',body)
        self.assertNotIn('anthropic_key',body)
    def test_session_start_chicago_dst(self):
        self.assertEqual(stamp(session_start(datetime(2026,10,8,15,tzinfo=UTC))),'2026-10-07T22:00:00Z')
        self.assertEqual(stamp(session_start(datetime(2026,12,8,15,tzinfo=UTC))),'2026-12-07T23:00:00Z')
    def test_real_accounts_rejected(self):
        b=Broker(self.s)
        b.accounts=lambda:[{'id':1,'canTrade':True,'simulated':False}]
        with self.assertRaises(RuntimeError):b.state()
    def test_only_mnq_contracts(self):
        self.assertTrue(is_mnq(self.broker.contract_rows[0]))
        self.assertFalse(is_mnq({'name':'NQZ6','tickSize':.25,'tickValue':5}))
    def test_save_keys_encrypted_mode_disarmed(self):
        if os.name!='nt':self.skipTest('Windows DPAPI only')
        path=Path(self.temp.name)/'settings.json'
        self.s.broker_key='broker-secret-12345'
        self.s.anthropic_key='anthropic-secret-12345'
        save_settings(path,self.s)
        raw=path.read_text()
        self.assertNotIn('broker-secret-12345',raw)
        self.assertNotIn('anthropic-secret-12345',raw)
        restored=load_settings(path)
        self.assertEqual(restored.broker_key,self.s.broker_key)
        self.assertEqual(restored.mode,'Preview only')
    def test_preview_flatten_has_no_mutations(self):
        self.s.mode='Preview only'
        with self.assertRaises(RuntimeError):self.engine.flatten()
        self.assertFalse(self.broker.placed)
    def test_stop_missing_position_flattens(self):
        self.engine.cycle()
        p=self.ledger.data['pending']
        p['created']=stamp(now()-timedelta(seconds=30))
        self.broker.history=[{'customTag':p['payload']['customTag'],'status':2}]
        self.broker.positions=[{'contractId':self.s.contract_id,'averagePrice':21000,'type':1,'size':1}]
        with self.assertRaises(RuntimeError):self.engine.cycle()
        self.assertFalse(self.broker.positions)
        self.assertTrue(self.engine.stop_event.is_set())

if __name__=='__main__':
    unittest.main(verbosity=2)
